const friendData = [
  {
    id: "1",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
  {
    id: "2",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
  {
    id: "3",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
  {
    id: "4",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
  {
    id: "5",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
  {
    id: "6",
    name: "priyanshu",
    backgroundImg: "https://source.unsplash.com/random/?adventure",
    profileImg: "https://source.unsplash.com/random/?boy",
    role: "Full Stack Developer",
    followers: "220",
  },
];

export default friendData;
