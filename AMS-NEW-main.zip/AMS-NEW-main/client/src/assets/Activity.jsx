const Activity = [
  {
    id: "1",
    postImg: "https://source.unsplash.com/random/?food",
    likes: "5",
    name: "Priyanshu Bhatt",
    timeStamp: "2h",
    postTitle: "Post 1",
    caption: "this is the first post of the project",
    followers: "15",
    comments: "14",
  },
];

export default Activity;
