const TopProfileData = [
  {
    id: 1,
    backgroundImg: "https://source.unsplash.com/random/?food",
    name: "Priyanshu Bhatt",
    bio: "Alumni batch 2024",
    district: "Dehradun",
    state: "Uttarakhand",
    country: "India",
    link: "#",
    phone: "1234567890",
    email: "nobody123@xyz.com",
  },
];

export default TopProfileData;
