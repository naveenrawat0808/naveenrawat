import React from "react";

const RightSideBar = () => {
  return <div>RightSideBar</div>;
};

export default RightSideBar;
