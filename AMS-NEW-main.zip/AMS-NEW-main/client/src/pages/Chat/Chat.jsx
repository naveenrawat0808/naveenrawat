import "./Chat.css";
import ChatBox from "./ChatBox";

function Chat() {
  return (
    <div className="back">
      <div className="head">
        <ChatBox />
      </div>
    </div>
  );
}

export default Chat;
